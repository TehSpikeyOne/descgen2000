CREATE DATABASE  IF NOT EXISTS `descgen2000` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `descgen2000`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: descgen2000
-- ------------------------------------------------------
-- Server version	5.6.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `floors`
--

DROP TABLE IF EXISTS `floors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `floors` (
  `idfloors` int(11) NOT NULL AUTO_INCREMENT,
  `desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idfloors`),
  UNIQUE KEY `floorscol_UNIQUE` (`desc`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `floors`
--

LOCK TABLES `floors` WRITE;
/*!40000 ALTER TABLE `floors` DISABLE KEYS */;
INSERT INTO `floors` VALUES (10,'Cold flagstones fit together tightly to form the floor, surprisingly even. Vapors rise slowly from the floor, showing up as spirals of translucent white.'),(15,'Frosted wood planks have been nailed together to create a sturdy floor for this <ROOM>.'),(14,'Glass-like tiles fit together at odd angles to create a <COLORDESC> mosaic in <COLOR>, <COLOR>, and <COLOR>.'),(8,'Luxurious shag rug in a <COLOR> color covers the floor, its pile rippling as it is trod upon.'),(12,'Packed dirt serves as the floor to this particular room, coming in a <COLORDESC> <COLOR> shade.'),(11,'Shallow carpeting fills the floor space between the walls here. It faintly resembles moss, but it is <COLORDESC> <COLOR>.'),(7,'Small ceramic tiles have been fit together into a chess board pattern, covering the floor in its entirety.'),(13,'The floor here shows an intricate design in ceramic tile. The <COLORS> and <COLORS> complimenting each other in a strange way.'),(9,'The floor is comprised of gleaming hardwood, stained and varnished to give it a glow that is present with absolutely any kind of light.'),(5,'Tiles laid in a perfectly symmetrical pattern make eye-numbing designs that stretch across the floor endlessly.'),(6,'Uneven planks of bare wood have been laid, following the lengthiest wall.');
/*!40000 ALTER TABLE `floors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-12-19 21:34:07
