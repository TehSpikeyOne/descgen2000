CREATE DATABASE  IF NOT EXISTS `descgen2000` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `descgen2000`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: descgen2000
-- ------------------------------------------------------
-- Server version	5.6.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `adjectives`
--

DROP TABLE IF EXISTS `adjectives`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `adjectives` (
  `idadjectives` int(11) NOT NULL AUTO_INCREMENT,
  `desc` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idadjectives`),
  UNIQUE KEY `adjectivescol_UNIQUE` (`desc`)
) ENGINE=InnoDB AUTO_INCREMENT=509 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adjectives`
--

LOCK TABLES `adjectives` WRITE;
/*!40000 ALTER TABLE `adjectives` DISABLE KEYS */;
INSERT INTO `adjectives` VALUES (476,'abnormal'),(282,'abominable'),(461,'alien'),(198,'ancient'),(350,'astronomical'),(425,'attractive'),(415,'autumn'),(213,'average'),(500,'baffling'),(285,'beautiful'),(212,'behemoth'),(499,'bewildering'),(210,'big'),(467,'bizarre'),(412,'broad'),(209,'bulky'),(250,'carved'),(319,'celestial'),(208,'colossal'),(268,'common'),(503,'commonplace'),(501,'confounding'),(262,'contoured'),(253,'crooked'),(204,'crowded'),(255,'crystalized'),(419,'crystalline'),(460,'cultivated'),(468,'curious breed of'),(256,'curved'),(413,'dark'),(245,'dead'),(456,'delicate'),(211,'demonic'),(283,'despicable'),(207,'diminutive'),(401,'dinky'),(251,'distinct'),(453,'disturbing'),(318,'divine'),(454,'dull'),(206,'dwarfed'),(402,'dwarfish'),(260,'elegant'),(410,'elephantine'),(214,'enormous'),(504,'everyday'),(267,'exalted'),(317,'extraordinary'),(259,'fancy'),(497,'fantastic'),(394,'fat'),(249,'foggy'),(462,'foreign'),(417,'fragile'),(477,'freakish'),(215,'giant'),(218,'gigantic'),(257,'glamorous'),(291,'glorious'),(246,'glowing'),(201,'gnarled'),(343,'good-sized'),(320,'gorgeous'),(289,'grandiose'),(219,'great'),(241,'groomed'),(354,'gross'),(258,'grotesque'),(344,'handsome'),(448,'healthy'),(416,'heavenly'),(244,'hollow'),(238,'homely'),(220,'huge'),(205,'hulking'),(269,'humble'),(221,'immense'),(290,'imposing'),(252,'indistinct'),(330,'insignificant'),(277,'inspiring'),(349,'insubstantial'),(423,'iridescent'),(355,'jumbo'),(242,'kempt'),(393,'large'),(345,'largish'),(414,'light'),(222,'little'),(264,'lofty'),(271,'lordly'),(270,'low'),(424,'lustrous'),(273,'magnanimous'),(274,'magnificent'),(261,'majestic'),(223,'mammoth'),(224,'massive'),(409,'meager'),(331,'measly'),(327,'mediocre'),(396,'midget'),(225,'miniature'),(226,'minute'),(247,'misty'),(325,'modest'),(411,'monolithic'),(288,'monumental'),(248,'motionless'),(502,'mystifying'),(286,'narrow'),(458,'nebulous'),(263,'noble'),(508,'nondescript'),(478,'notable'),(459,'obscuring'),(200,'old'),(323,'opulent'),(265,'ordinary'),(346,'oversized'),(507,'patchwork'),(240,'peaceful'),(422,'pearlescent'),(227,'petite'),(397,'pint-sized'),(427,'potent'),(428,'powerful'),(276,'princely'),(228,'prodigious'),(239,'pruned'),(229,'puny'),(403,'pygmy'),(237,'quaint'),(266,'regal'),(475,'remarkable'),(321,'resplendent'),(445,'robust'),(328,'run-of-the-mill'),(406,'scant'),(404,'scarce'),(408,'scrubby'),(451,'seamless'),(322,'sensational'),(457,'serene'),(329,'shabby'),(235,'shadowy'),(236,'shady'),(196,'short'),(202,'sickly'),(347,'sizeable'),(399,'slight'),(230,'small'),(418,'smoky'),(452,'smooth'),(421,'solid'),(278,'sordid'),(405,'sparse'),(420,'speckled'),(316,'splendiferous'),(216,'split'),(203,'sporadic'),(279,'squalid'),(466,'strange'),(479,'striking'),(407,'stunted'),(231,'stupendous'),(272,'sublime'),(348,'substantial'),(324,'sumptuous'),(426,'superior'),(197,'tall'),(398,'teeny'),(455,'tender'),(395,'thick'),(400,'thin'),(217,'thunderstruck'),(234,'towering'),(314,'tremendous'),(254,'twisted'),(284,'ugly'),(496,'uncommon'),(450,'unhealthy'),(506,'uniform'),(498,'unique'),(243,'unkempt'),(463,'unnatural'),(326,'unprepossessing'),(464,'unrealistic'),(505,'usual'),(233,'vast'),(275,'venerable'),(447,'vigorous'),(280,'vile'),(199,'vine-covered'),(446,'vitalized'),(232,'voluminous'),(449,'weak'),(287,'wide'),(465,'wild'),(315,'wonderful'),(313,'wondrous'),(281,'wretched');
/*!40000 ALTER TABLE `adjectives` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-12-19 21:34:09
