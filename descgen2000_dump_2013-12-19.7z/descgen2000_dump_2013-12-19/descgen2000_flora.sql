CREATE DATABASE  IF NOT EXISTS `descgen2000` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `descgen2000`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: descgen2000
-- ------------------------------------------------------
-- Server version	5.6.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `flora`
--

DROP TABLE IF EXISTS `flora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `flora` (
  `idflora` int(11) NOT NULL AUTO_INCREMENT,
  `desc` varchar(45) DEFAULT NULL,
  `plural` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idflora`),
  UNIQUE KEY `desc_UNIQUE` (`desc`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flora`
--

LOCK TABLES `flora` WRITE;
/*!40000 ALTER TABLE `flora` DISABLE KEYS */;
INSERT INTO `flora` VALUES (1,'fern',NULL),(2,'forget-me-not',NULL),(3,'hibiscus',NULL),(4,'morning glory',NULL),(5,'acacia',NULL),(6,'rose',NULL),(7,'catnip',NULL),(8,'petunia',NULL),(9,'poinsettia',NULL),(10,'blueberry',NULL),(11,'cucumber',NULL),(12,'berry',NULL),(13,'blackberry',NULL),(14,'ivy',NULL),(15,'grass',NULL),(16,'foxglove',NULL),(17,'orchid',NULL),(18,'rhododendron',NULL),(19,'honeysuckle',NULL),(20,'goldenrod',NULL),(21,'gladioli',NULL),(22,'bellflower',NULL),(23,'paintbrush',NULL),(24,'camellia',NULL),(25,'chrysanthemum',NULL),(26,'sweet pea',NULL),(27,'tulip',NULL),(28,'viola',NULL),(29,'vegetation',NULL),(30,'water lily',NULL),(31,'windflower',NULL),(32,'witch hazel',NULL),(33,'hydrangea',NULL),(34,'iris',NULL),(35,'lily',NULL),(36,'magnolia',NULL),(37,'daisy',NULL),(38,'mistletoe',NULL),(39,'diascia',NULL),(40,'dahlia',NULL),(41,'daffodil',NULL),(42,'crocus',NULL),(43,'hosta',NULL),(44,'shrubbery',NULL),(45,'flytrap',NULL),(46,'strawberry',NULL),(47,'teaberry',NULL),(48,'Queen Anne\'s lace',NULL),(49,'snapdragon',NULL),(50,'summer poinsettia',NULL),(51,'smilax',NULL),(52,'kangaroo paw',NULL),(53,'foxtail fern',NULL),(54,'plumosus fern',NULL),(55,'ming fern',NULL),(56,'tree fern',NULL),(57,'fungus',NULL),(58,'mushroom',NULL),(59,'burr',NULL),(60,'aster',NULL),(61,'silver lace',NULL),(62,'bamboo',NULL),(63,'banksia',NULL),(64,'beforthia',NULL),(65,'bouvardia',NULL),(66,'cabbage',NULL),(67,'corn',NULL),(68,'sunflower',NULL),(69,'thoroughwax plant',NULL),(70,'boxwood',NULL),(71,'caleanthus',NULL),(72,'heather',NULL),(73,'baby\'s breath',NULL),(74,'waxflower',NULL),(75,'pompons',NULL),(76,'mum',NULL),(77,'thistle',NULL),(78,'lily of the valley',NULL),(79,'billy buttons',NULL),(80,'cymbidium',NULL),(81,'artichoke',NULL),(82,'umbrella plant',NULL),(83,'papyrus',NULL),(84,'lion\'s head papyrus',NULL),(85,'larkspur',NULL),(86,'belladonna',NULL),(87,'delphinium',NULL),(88,'carnation',NULL),(89,'gipsy bloom',NULL),(90,'hop bush',NULL),(91,'globe thistle',NULL),(92,'horsetail',NULL),(93,'cattail',NULL),(94,'sea holly',NULL),(95,'moon lagoon',NULL),(96,'lisianthus',NULL),(97,'freesia',NULL),(98,'gardenia',NULL),(99,'gerbera',NULL),(100,'orchidiolas',NULL),(101,'honey bracelet',NULL),(102,'coffee bean bush',NULL),(103,'kunzea',NULL),(104,'lavender',NULL),(105,'lilac',NULL),(106,'lepto',NULL),(107,'leucadendron',NULL),(108,'protea',NULL),(109,'gayfeather',NULL),(110,'privit',NULL),(111,'lilium',NULL),(112,'limonium',NULL),(113,'lily grass',NULL),(114,'luma',NULL),(115,'matthiola incana',NULL),(116,'philodendron',NULL),(117,'sword fern',NULL),(118,'poppy',NULL),(119,'geranium',NULL),(120,'flax',NULL),(121,'tuberose',NULL),(122,'buckthorn',NULL),(123,'sweetheart',NULL),(124,'tea rose',NULL),(125,'rosemary',NULL),(126,'thyme',NULL),(127,'leatherleaf fern',NULL),(128,'ruscus',NULL),(129,'saponaria',NULL),(130,'pepperberry',NULL),(131,'solidaster',NULL),(132,'jasmine',NULL),(133,'bird of paradise',NULL),(134,'trachelium',NULL),(135,'speedwell',NULL),(136,'calla',NULL),(137,'lupine',NULL),(138,'toadflax',NULL),(139,'black-eyed susan',NULL),(140,'blazing star',NULL),(141,'blanket flower',NULL),(142,'sage',NULL),(143,'butterfly weed',NULL),(144,'calendula',NULL),(145,'candytuft',NULL),(146,'chicory',NULL),(147,'clasping coneflower',NULL),(148,'cosmos',NULL),(149,'clover',NULL),(150,'dame\'s rocket',NULL),(151,'marigold',NULL),(152,'phlox',NULL),(153,'primrose',NULL),(154,'farewell-to-spring',NULL),(155,'five spot',NULL),(156,'godetia',NULL),(157,'hollyhock',NULL),(158,'johnny jump-up',NULL),(159,'lacy phacelia',NULL),(160,'lemon mint',NULL),(161,'mint',NULL),(162,'moss',NULL),(163,'nasturtium',NULL),(164,'catchfly',NULL),(165,'prairie clover',NULL),(166,'rose mallow',NULL),(167,'sweet alyssum',NULL),(168,'bluebonnet',NULL),(169,'zinnia',NULL),(170,'cactus',NULL),(171,'alfalfa',NULL),(172,'rabbitsfoot grass',NULL),(173,'tobacco',NULL),(174,'grape',NULL),(175,'duckweed',NULL),(176,'monkeyflower',NULL),(177,'cocklebur',NULL),(178,'buttercup',NULL),(179,'bursage',NULL),(180,'gooseberry',NULL),(181,'hedgenettle',NULL),(182,'heliotrope',NULL),(183,'horseweed',NULL),(184,'lessingia',NULL),(185,'marsh primrose',NULL),(186,'milkweed',NULL),(187,'nitrophila',NULL),(188,'mugwort',NULL),(189,'lettuce',NULL),(190,'sacred datura',NULL),(191,'sand spurrey',NULL),(192,'smartweed',NULL),(193,'ladysthumb',NULL),(194,'spikeweed',NULL),(212,'stinging nettle',NULL),(213,'yerba mansa',NULL),(214,'burclover',NULL),(215,'chickweed',NULL),(216,'dwarf nettle',NULL),(217,'knotweed',NULL),(218,'shepherd\'s purse',NULL),(219,'spearmint',NULL),(220,'sow thistle',NULL),(221,'sweet clover',NULL),(222,'vetch',NULL),(223,'radish',NULL),(224,'watermelon',NULL),(225,'woolly mullein',NULL),(226,'creeping wild rye',NULL),(227,'foxtail',NULL),(228,'oats',NULL),(229,'witch grass',NULL),(230,'horseradish',NULL),(231,'beet',NULL),(232,'gourd',NULL),(233,'squash',NULL),(234,'pricker bush',NULL),(235,'tomato',NULL),(236,'zuccini',NULL),(237,'pumpkin',NULL),(238,'melon',NULL),(239,'hay',NULL),(240,'creeper',NULL),(241,'hemp',NULL),(242,'lotus',NULL),(243,'lily pad',NULL),(244,'poison ivy',NULL),(245,'wild strawberry',NULL),(246,'bramble',NULL),(247,'tumbleweed',NULL),(248,'peacock plant',NULL),(249,'poison creeper',NULL),(250,'poison oak',NULL),(251,'salvia divinorum',NULL),(252,'tall grass',NULL),(253,'aloe',NULL),(254,'pineapple',NULL),(255,'linen',NULL);
/*!40000 ALTER TABLE `flora` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-12-19 21:34:09
