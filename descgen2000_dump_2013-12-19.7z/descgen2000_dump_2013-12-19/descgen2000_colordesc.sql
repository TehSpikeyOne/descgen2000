CREATE DATABASE  IF NOT EXISTS `descgen2000` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `descgen2000`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: descgen2000
-- ------------------------------------------------------
-- Server version	5.6.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `colordesc`
--

DROP TABLE IF EXISTS `colordesc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `colordesc` (
  `idcolordesc` int(11) NOT NULL AUTO_INCREMENT,
  `desc` varchar(45) DEFAULT NULL,
  `plural` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idcolordesc`),
  UNIQUE KEY `colordesccol_UNIQUE` (`desc`)
) ENGINE=InnoDB AUTO_INCREMENT=290 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colordesc`
--

LOCK TABLES `colordesc` WRITE;
/*!40000 ALTER TABLE `colordesc` DISABLE KEYS */;
INSERT INTO `colordesc` VALUES (146,'bright',NULL),(147,'icy',NULL),(148,'dark',NULL),(149,'light',NULL),(150,'vivid',NULL),(151,'vibrant',NULL),(152,'soft',NULL),(153,'gentle',NULL),(154,'bold',NULL),(155,'jet',NULL),(156,'ash',NULL),(157,'autumn',NULL),(158,'bisque',NULL),(159,'burnt',NULL),(160,'crisp',NULL),(161,'deep',NULL),(162,'heavenly',NULL),(163,'jewel-like',NULL),(164,'fragile',NULL),(165,'smoky',NULL),(166,'swirly',NULL),(167,'oceanic',NULL),(168,'toasted',NULL),(169,'crystal',NULL),(170,'crystalline',NULL),(171,'speckled',NULL),(172,'solid',NULL),(173,'graduated',NULL),(174,'pearlescent',NULL),(175,'iridescent',NULL),(176,'lustrous',NULL),(177,'attractive',NULL),(178,'glamorous',NULL),(179,'superior',NULL),(180,'powerful',NULL),(181,'robust',NULL),(182,'vitalized',NULL),(183,'vigorous',NULL),(184,'healthy',NULL),(185,'weak',NULL),(186,'impotent',NULL),(187,'slight',NULL),(188,'unhealthy',NULL),(189,'sharp',NULL),(190,'full-bodied',NULL),(191,'seamless',NULL),(192,'smooth',NULL),(193,'smart',NULL),(194,'bitter',NULL),(195,'disturbing',NULL),(196,'exciting',NULL),(197,'distressing',NULL),(198,'almost painful',NULL),(199,'invigorating',NULL),(200,'dull',NULL),(201,'zesty',NULL),(202,'keen',NULL),(203,'provocative',NULL),(204,'bland',NULL),(205,'mellow',NULL),(206,'flat',NULL),(207,'heavy',NULL),(208,'rich',NULL),(209,'full',NULL),(210,'potent',NULL),(211,'striped',NULL),(212,'undiluted',NULL),(213,'diluted',NULL),(214,'hazy',NULL),(215,'watery',NULL),(216,'equiable',NULL),(217,'tender',NULL),(218,'benign',NULL),(219,'delicate',NULL),(220,'serene',NULL),(221,'violent',NULL),(222,'abrasive',NULL),(223,'scathing',NULL),(224,'unclouded',NULL),(225,'cloudy',NULL),(226,'steely',NULL),(227,'picturesque',NULL),(228,'expressive',NULL),(229,'fresh',NULL),(230,'natural',NULL),(231,'nebulous',NULL),(232,'obscure',NULL),(233,'proper',NULL),(234,'magnificent',NULL),(235,'elemental',NULL),(236,'inherent',NULL),(237,'cultivated',NULL),(238,'alien',NULL),(239,'foreign',NULL),(240,'unnatural',NULL),(241,'unrealistic',NULL),(242,'true',NULL),(243,'off',NULL),(244,'contrasting',NULL),(245,'wild',NULL),(246,'untamed',NULL),(247,'unsubdued',NULL),(248,'subdued',NULL),(249,'tamed',NULL),(250,'polka-dotted',NULL),(251,'odd',NULL),(252,'furious',NULL),(253,'strange',NULL),(254,'unmatched',NULL),(255,'bizarre',NULL),(256,'curious',NULL),(257,'outlandish',NULL),(258,'peculiar',NULL),(259,'quaint',NULL),(260,'queer',NULL),(261,'quirky',NULL),(262,'remarkable',NULL),(263,'weird',NULL),(264,'abnormal',NULL),(265,'freakish',NULL),(266,'phenomenal',NULL),(267,'notable',NULL),(268,'striking',NULL),(269,'atrocious',NULL),(270,'shocking',NULL),(271,'unconventional',NULL),(272,'uncommon',NULL),(273,'rare',NULL),(274,'fantastic',NULL),(275,'aberrant',NULL),(276,'unique',NULL),(277,'bewildering',NULL),(278,'baffling',NULL),(279,'confounding',NULL),(280,'mystifying',NULL),(281,'commonplace',NULL),(282,'everyday',NULL),(283,'unexceptional',NULL),(284,'usual',NULL),(285,'expected',NULL),(286,'familiar',NULL),(287,'predictable',NULL),(288,'wonted',NULL),(289,'unwonted',NULL);
/*!40000 ALTER TABLE `colordesc` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-12-19 21:34:06
