CREATE DATABASE  IF NOT EXISTS `descgen2000` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `descgen2000`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: descgen2000
-- ------------------------------------------------------
-- Server version	5.6.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `colors`
--

DROP TABLE IF EXISTS `colors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `colors` (
  `idcolors` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idcolors`),
  UNIQUE KEY `colorscol_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `colors`
--

LOCK TABLES `colors` WRITE;
/*!40000 ALTER TABLE `colors` DISABLE KEYS */;
INSERT INTO `colors` VALUES (109,'alabaster'),(101,'almond'),(133,'amethyst'),(115,'an'),(104,'aquamarine'),(95,'azure'),(96,'beige'),(99,'bisque'),(87,'black'),(72,'blue'),(124,'brass'),(79,'brown'),(80,'cerulean'),(107,'chartreuse'),(106,'chocolate'),(136,'cobalt'),(91,'coral'),(112,'cornsilk'),(113,'crimson'),(78,'cyan'),(125,'dune'),(130,'emerald'),(94,'fuschia'),(85,'gold'),(82,'golden'),(73,'green'),(110,'green-yellow'),(88,'grey'),(111,'honeydew'),(74,'indigo'),(129,'jade'),(139,'jet black'),(114,'khaki'),(116,'lavender'),(97,'lime'),(105,'linen'),(103,'magenta'),(126,'mahogany'),(102,'maroon'),(138,'mauve'),(127,'midnight'),(117,'olive'),(134,'onyx'),(132,'opalescent'),(75,'orange'),(119,'orange-red'),(121,'orchid'),(98,'peach'),(135,'peridot'),(76,'pink'),(92,'plum'),(93,'puse'),(137,'rainbow'),(71,'red'),(77,'rose'),(131,'ruby'),(90,'salmon'),(128,'sapphire'),(108,'sienna'),(86,'silver'),(83,'silvery'),(118,'tomato'),(100,'turquoise'),(122,'umber'),(89,'violet'),(120,'wheat'),(84,'white'),(123,'wine'),(81,'yellow');
/*!40000 ALTER TABLE `colors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-12-19 21:34:07
