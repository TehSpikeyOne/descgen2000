CREATE DATABASE  IF NOT EXISTS `descgen2000` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `descgen2000`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: descgen2000
-- ------------------------------------------------------
-- Server version	5.6.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `building`
--

DROP TABLE IF EXISTS `building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `building` (
  `idbuilding` int(11) NOT NULL AUTO_INCREMENT,
  `desc` varchar(45) DEFAULT NULL,
  `plural` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idbuilding`),
  UNIQUE KEY `desc_UNIQUE` (`desc`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `building`
--

LOCK TABLES `building` WRITE;
/*!40000 ALTER TABLE `building` DISABLE KEYS */;
INSERT INTO `building` VALUES (1,'senate',NULL),(2,'playhouse',NULL),(3,'house',NULL),(4,'arena',NULL),(5,'ballroom',NULL),(6,'hippodrome',NULL),(7,'ampitheater',NULL),(8,'lyceum',NULL),(9,'residency',NULL),(10,'aerie',NULL),(11,'penthouse',NULL),(12,'salon',NULL),(13,'suite',NULL),(14,'townhouse',NULL),(15,'nest',NULL),(16,'pad',NULL),(17,'place',NULL),(18,'home',NULL),(19,'habitation',NULL),(20,'dwelling',NULL),(21,'showplace',NULL),(22,'abode',NULL),(23,'domicile',NULL),(24,'castle',NULL),(25,'chateau',NULL),(26,'countryseat',NULL),(27,'estate',NULL),(28,'hacienda',NULL),(29,'manor',NULL),(30,'manor house',NULL),(31,'hall',NULL),(32,'palace',NULL),(33,'villa',NULL),(34,'mansion',NULL),(35,'lodging',NULL),(36,'hearth',NULL),(37,'accomodations',NULL),(38,'shelter',NULL),(39,'bungalow',NULL),(40,'chalet',NULL),(41,'cabin',NULL),(42,'cottage',NULL),(43,'ranch',NULL),(44,'barracks',NULL),(45,'boardinghouse',NULL),(46,'dormitory',NULL),(47,'lodging house',NULL),(48,'rooming house',NULL),(49,'shack',NULL),(50,'hut',NULL),(51,'hovel',NULL),(52,'niche',NULL),(53,'range',NULL),(54,'orphanage',NULL),(55,'office building',NULL),(56,'store',NULL);
/*!40000 ALTER TABLE `building` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-12-19 21:34:08
